import boto3
import requests
from BucketACLS import audit_bucket_acl
import json
import os
s3 = boto3.client('s3')
# region = os.environ['AWS_REGION']
# ec2_ip = os.environ['opa_server_ip']
region = "us-east-1"
    

       
try:
        with open("../../../../setup_config.json", "r") as config_file:
            config_data = json.load(config_file)
            account_id=config_data.get('accountId')
                

except Exception as e:
    print(e)
# def lambda_handler(event, context):
#     # bucket_name = event.get['bucket_name']
#     bucket_name="sujalbuckettestcspm"
#     try:
#         tagset = s3.get_bucket_tagging(Bucket=bucket_name)
#     except Exception as e:
#          tagset = ""
#     # audit_bucket_acl(bucket_name=bucket_name,account_id=account_id,region=region,tagset=tagset)
bucket_name="sujalbuckettestcspm"
try:
    tagset = s3.get_bucket_tagging(Bucket=bucket_name)['TagSet']
    
except Exception as e:
    tagset = [{"Key":"None","Value":"None"}]
audit_bucket_acl(bucket_name=bucket_name,accountId=account_id,region=region,tagset=tagset)
