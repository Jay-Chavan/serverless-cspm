import boto3
from helper_functions.hashing import calculate_md5
import random
from datetime import datetime, timezone
import requests
import os

operation="Bucket_Acl"
ec2_ip = os.environ['opa_server_ip']
url = f"http://{ec2_ip}:8181/v1/data/aws/s3_creation/deny"

def audit_bucket_acl(bucket_name,accountId,region,tagset):
  id=calculate_md5(bucket_name+operation+str(random.random()))
  s3 = boto3.client('s3')
  bucket_ownership=s3.get_bucket_ownership_controls(Bucket=bucket_name)['OwnershipControls']['Rules'][0]['ObjectOwnership']
  public_access = {"input":{"resource_type":"s3","bucket_config":{"bucket_ownership":bucket_ownership,"tagset":tagset}}}
  
  opa_response = requests.post(url=url,json=public_access)
  risk = opa_response.json()['result']['risk_level']
  reason = opa_response.json()['result']['reason']
  if "Unrecognized" in risk:
    risk = "Critical"
  if risk == "Public":
    
    return False
  
  
  
  finding_timestamp=datetime.now(timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')
  finding = {
        "Finding": [
          {
            "SchemaVersion": "2018-10-08",
            "Id": f"{id}",
            "ProductArn": f"arn:aws:securityhub:<region>::product/{accountId}/default",
            "GeneratorId": "cspm",
            "AwsAccountId": f"{accountId}",
            "Domain" : "Data Storage",
            "Types": "Bucket Configuration Checks",
            "CreatedAt": finding_timestamp,
            "UpdatedAt": finding_timestamp,
            "Severity": {
              "risk_level":risk,
              "reason": reason
              
            },
            "Title": "S3 Bucket with public ACL",
            "Description": f"The bucket {bucket_name} has ACL enabled with {bucket_ownership}.",
            "Resources": [
              {
                "Type": "AwsS3Bucket",
                "Id": f"arn:aws:s3:::{bucket_name}",
                "Partition": "aws",
                "Region": f"{region}"
              }
            ]
          }
    ]
  }


  print(finding)
